self.__precacheManifest = [
  {
    "revision": "dd949c7a9edbcd7b921b",
    "url": "/preview/gv7edvg8/static/css/main.4161a246.chunk.css"
  },
  {
    "revision": "dd949c7a9edbcd7b921b",
    "url": "/preview/gv7edvg8/static/js/main.50b4d415.chunk.js"
  },
  {
    "revision": "cf4a41aec152a455ed01",
    "url": "/preview/gv7edvg8/static/js/runtime~main.66a9b3a4.js"
  },
  {
    "revision": "6c83df8406b697a84af6",
    "url": "/preview/gv7edvg8/static/js/2.3b342385.chunk.js"
  },
  {
    "revision": "04720ca295c5d73af6bf59884accbcc0",
    "url": "/preview/gv7edvg8/index.html"
  }
];